/**
 * Senoobar — Wishlist page + product-card heart button.
 *
 * Storage:
 *  - Logged-in -> server (user meta), synced via AJAX.
 *  - Guest     -> localStorage under 'senoobar_wishlist'.
 */
(function () {
  'use strict';

  const LS_KEY = 'senoobar_wishlist';
  const $ = (s, c) => (c || document).querySelector(s);
  const $$ = (s, c) => [...(c || document).querySelectorAll(s)];

  const ajaxUrl = (window.senoobarData && senoobarData.ajaxUrl) || '/wp-admin/admin-ajax.php';

  // ── Local list (guest) ────────────────────────────────
  function getLocal() {
    try {
      const v = JSON.parse(localStorage.getItem(LS_KEY) || '[]');
      return Array.isArray(v) ? v.map(Number) : [];
    } catch (_) { return []; }
  }
  function setLocal(ids) {
    try { localStorage.setItem(LS_KEY, JSON.stringify(ids.map(Number))); } catch (_) {}
  }

  function isLoggedIn() {
    // Trust the server-side flag first (senoobarData.loggedIn =
    // is_user_logged_in()). The body.logged-in class is unreliable because it
    // is also added by the admin bar / other plugins for non-customers.
    if (window.senoobarData && typeof senoobarData.loggedIn === 'boolean') {
      return senoobarData.loggedIn;
    }
    if (window.SENOOBAR_WISHLIST && typeof SENOOBAR_WISHLIST.loggedIn === 'boolean') {
      return SENOOBAR_WISHLIST.loggedIn;
    }
    return document.body.classList.contains('logged-in');
  }

  // Server-exposed wishlist ids for logged-in users (set by page-wishlist.php)
  function getServerIds() {
    return (window.SENOOBAR_WISHLIST && Array.isArray(window.SENOOBAR_WISHLIST.ids))
      ? window.SENOOBAR_WISHLIST.ids.map(Number)
      : null;
  }

  // ── Network ─────────────────────────────────────────
  async function post(action, data) {
    const body = new FormData();
    for (const k in data) {
      const v = data[k];
      if (Array.isArray(v)) {
        v.forEach((item) => body.append(k + '[]', item));
      } else {
        body.append(k, v);
      }
    }
    body.append('action', action);
    const res = await fetch(ajaxUrl, { method: 'POST', credentials: 'same-origin', body });
    return res.json();
  }

  // ── Toggle a product in the wishlist (product page heart) ──
  async function toggle(productId) {
    if (isLoggedIn()) {
      const r = await post('senoobar_wishlist_toggle', { product_id: productId });
      if (r && r.success) return r.data.in_wishlist;
      return false;
    } else {
      let ids = getLocal();
      let added;
      if (ids.includes(productId)) {
        ids = ids.filter((x) => x !== productId);
        added = false;
      } else {
        ids.push(productId);
        added = true;
      }
      setLocal(ids);
      return added;
    }
  }

  // ── Read current wishlist ids (merged) ─────────────
  async function getIds() {
    if (isLoggedIn()) {
      const server = getServerIds();
      if (server !== null) return server;
      const r = await post('senoobar_wishlist_get', {});
      return (r && r.success && r.data.ids) || [];
    }
    return getLocal();
  }

  // ── Format price to Persian ────────────────────────
  function fmt(n) {
    const num = Number(n) || 0;
    return num.toLocaleString('fa-IR');
  }
  function escapeHtml(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({
      '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;',
    }[c]));
  }

  // ── Render cards into the grid ─────────────────────
  function render(items, view) {
    const grid = $('#snbWishGrid');
    if (!grid) return;

    const empty = $('#snbWishEmpty');
    const cta = $('#snbWishCta');
    const countEl = $('#snbWishCount');

    if (!items.length) {
      grid.innerHTML = '';
      grid.querySelectorAll('*').forEach((n) => n.remove());
      if (empty) empty.style.display = 'flex';
      if (cta) cta.style.display = 'none';
      if (countEl) countEl.textContent = '0 محصول ذخیره شده';
      return;
    }

    if (empty) empty.style.display = 'none';
    if (cta) cta.style.display = 'flex';
    if (countEl) {
      const word = items.length === 1 ? 'محصول' : 'محصول';
      countEl.textContent = items.length + ' ' + word + ' ذخیره شده';
    }

    grid.innerHTML = items.map((it) => {
      const cat = (it.cats && it.cats[0]) || '';
      const sale = it.sale_price && Number(it.sale_price) < Number(it.regular_price);
      const price = sale ? it.sale_price : it.price;
      const old = sale ? it.regular_price : '';

      if (view === 'list') {
        return `
          <div class="snb-wish-item snb-wish-item--list" data-id="${it.id}">
            <a href="${escapeHtml(it.permalink)}" class="snb-wish-img-wrap">
              <img src="${escapeHtml(it.image)}" alt="${escapeHtml(it.name)}" loading="lazy">
              ${!it.in_stock ? '<span class="snb-wish-nostock">ناموجود</span>' : ''}
            </a>
            <div class="snb-wish-body snb-wish-body--list">
              <div class="snb-wish-info">
                ${cat ? `<span class="snb-wish-cat">${escapeHtml(cat)}</span>` : ''}
                <a href="${escapeHtml(it.permalink)}" class="snb-wish-name">${escapeHtml(it.name)}</a>
              </div>
              <div class="snb-wish-pricebox">
                <span class="snb-wish-price">${fmt(price)} <small>تومان</small></span>
                ${old ? `<span class="snb-wish-old">${fmt(old)}</span>` : ''}
              </div>
              <div class="snb-wish-actions">
                <button type="button" class="snb-wish-addcart" data-addcart="${it.id}" ${!it.in_stock ? 'disabled' : ''}>
                  افزودن به سبد
                </button>
                <button type="button" class="snb-wish-remove" data-remove="${it.id}">حذف</button>
              </div>
            </div>
            <button type="button" class="snb-wish-x" data-remove="${it.id}" aria-label="حذف">✕</button>
          </div>`;
      }

      return `
        <div class="snb-wish-item" data-id="${it.id}">
          <button type="button" class="snb-wish-x" data-remove="${it.id}" aria-label="حذف">✕</button>
          ${!it.in_stock ? '<span class="snb-wish-nostock-badge">ناموجود</span>' : ''}
          <a href="${escapeHtml(it.permalink)}" class="snb-wish-img-wrap">
            <img src="${escapeHtml(it.image)}" alt="${escapeHtml(it.name)}" loading="lazy">
          </a>
          <div class="snb-wish-body">
            ${cat ? `<span class="snb-wish-cat">${escapeHtml(cat)}</span>` : ''}
            <a href="${escapeHtml(it.permalink)}" class="snb-wish-name">${escapeHtml(it.name)}</a>
            <div class="snb-wish-pricebox">
              <span class="snb-wish-price">${fmt(price)} <small>تومان</small></span>
              ${old ? `<span class="snb-wish-old">${fmt(old)}</span>` : ''}
            </div>
            <button type="button" class="snb-wish-addcart" data-addcart="${it.id}" ${!it.in_stock ? 'disabled' : ''}>
              افزودن به سبد خرید
            </button>
          </div>
        </div>`;
    }).join('');
  }

  // ── Init wishlist page ─────────────────────────────
  async function initPage() {
    const grid = $('#snbWishGrid');
    if (!grid) return;

    let currentView = 'grid';
    let currentSort = 'default';
    let items = [];

    // Fetch merged wishlist ids + full items
    const ids = await getIds();
    if (ids.length) {
      const r = await post('senoobar_wishlist_render', { ids });
      if (r && r.success) items = r.data.items || [];
    }

    function applySort(list) {
      const arr = [...list];
      if (currentSort === 'price-asc') arr.sort((a, b) => Number(a.price) - Number(b.price));
      else if (currentSort === 'price-desc') arr.sort((a, b) => Number(b.price) - Number(a.price));
      return arr;
    }

    function refresh() {
      const sorted = applySort(items);
      render(sorted, currentView);
      grid.dataset.view = currentView;
    }

    // Sort
    const sortSel = $('#snbWishSort');
    if (sortSel) {
      sortSel.addEventListener('change', () => {
        currentSort = sortSel.value;
        refresh();
      });
    }

    // View toggle
    $$('.snb-wish-view-btn').forEach((btn) => {
      btn.addEventListener('click', () => {
        currentView = btn.dataset.view;
        $$('.snb-wish-view-btn').forEach((b) => b.classList.remove('is-active'));
        btn.classList.add('is-active');
        refresh();
      });
    });

    // Delegated remove
    grid.addEventListener('click', async (e) => {
      const rm = e.target.closest('[data-remove]');
      if (rm) {
        e.preventDefault();
        const id = Number(rm.dataset.remove);
        if (isLoggedIn()) {
          await post('senoobar_wishlist_toggle', { product_id: id });
        } else {
          setLocal(getLocal().filter((x) => x !== id));
        }
        items = items.filter((it) => Number(it.id) !== id);
        refresh();
      }
    });

    // Delegated add-to-cart (use WooCommerce AJAX)
    grid.addEventListener('click', async (e) => {
      const btn = e.target.closest('[data-addcart]');
      if (!btn) return;
      e.preventDefault();
      const id = btn.dataset.addcart;
      btn.disabled = true;
      btn.textContent = 'در حال افزودن...';
      try {
        // jQuery-based wc add_to_cart is available globally on the site.
        if (window.jQuery) {
          window.jQuery('body').trigger('added_to_cart', []);
        }
        const r = await post('senoobar_add_to_cart', { product_id: id });
        if (r && r.success) {
          btn.textContent = '✓ اضافه شد';
          if (window.jQuery) window.jQuery(document.body).trigger('wc_fragment_refresh');
        } else {
          btn.textContent = 'خطا، دوباره تلاش کنید';
          btn.disabled = false;
        }
      } catch (_) {
        btn.textContent = 'خطا، دوباره تلاش کنید';
        btn.disabled = false;
      }
    });

    refresh();
  }

  // ── Product/card heart button toggle ────────────────
  // Uses document-level delegation so it keeps working after AJAX filter /
  // infinite-scroll replace the product cards.
  function initHeartButtons() {
    async function paint(btn) {
      const id = Number(btn.getAttribute('data-wishlist-btn'));
      const inList = isLoggedIn()
        ? (await getIds()).includes(id)
        : getLocal().includes(id);
      btn.classList.toggle('is-active', inList);
      const label = btn.querySelector('[data-wishlist-label]');
      if (label) label.textContent = inList ? 'در علاقه‌مندی‌ها' : 'افزودن به علاقه‌مندی';
    }

    // Paint hearts that already exist on the page.
    $$('[data-wishlist-btn]').forEach(paint);

    // Delegated click handler (runs once, survives DOM replacement).
    document.addEventListener('click', async (e) => {
      const btn = e.target.closest('[data-wishlist-btn]');
      if (!btn) return;

      // Don't let the click reach the wrapping product link.
      e.preventDefault();
      e.stopPropagation();

      const id = Number(btn.getAttribute('data-wishlist-btn'));
      const nowActive = await toggle(id);

      // Reflect the new state immediately.
      btn.classList.toggle('is-active', nowActive);
      const label = btn.querySelector('[data-wishlist-label]');
      if (label) label.textContent = nowActive ? 'در علاقه‌مندی‌ها' : 'افزودن به علاقه‌مندی';

      // Also update any other heart with the same product id in the DOM.
      $$('[data-wishlist-btn="' + id + '"]').forEach((b) => {
        if (b !== btn) {
          b.classList.toggle('is-active', nowActive);
          const l = b.querySelector('[data-wishlist-label]');
          if (l) l.textContent = nowActive ? 'در علاقه‌مندی‌ها' : 'افزودن به علاقه‌مندی';
        }
      });
    });
  }

  // ── Card qty stepper (replaces "view cart" after adding) ──
  // After a product is added to the cart (WooCommerce 'added_to_cart'), show a
  // compact [-] qty [+] [remove] control in place of the round cart button.
  let stepperQty = {}; // product_id -> quantity (best-effort cache)

  function buildStepper(productId, initialQty) {
    const wrap = document.createElement('div');
    wrap.className = 'snb-card-stepper';
    wrap.setAttribute('data-card-stepper', productId);

    const minus = document.createElement('button');
    minus.type = 'button';
    minus.className = 'snb-card-minus';
    minus.innerHTML = '&minus;';
    minus.setAttribute('aria-label', 'کاهش تعداد');

    const qty = document.createElement('span');
    qty.className = 'snb-card-qty';
    qty.textContent = initialQty;

    const plus = document.createElement('button');
    plus.type = 'button';
    plus.className = 'snb-card-plus';
    plus.innerHTML = '+';
    plus.setAttribute('aria-label', 'افزایش تعداد');

    const del = document.createElement('button');
    del.type = 'button';
    del.className = 'snb-card-del';
    del.innerHTML = '&#128465;';
    del.setAttribute('aria-label', 'حذف از سبد');

    // "View cart" button — shown beside the stepper.
    const view = document.createElement('a');
    view.href = (window.senoobarData && senoobarData.cartUrl) || '/cart/';
    view.className = 'snb-card-view';
    view.textContent = 'مشاهده سبد خرید';

    wrap.appendChild(minus);
    wrap.appendChild(qty);
    wrap.appendChild(plus);
    wrap.appendChild(del);
    wrap.appendChild(view);

    return { wrap, qty };
  }

  async function cardCartPost(action, productId, quantity) {
    const nonce = (window.senoobarData && senoobarData.nonce) || '';
    const body = new FormData();
    body.append('action', action);
    body.append('nonce', nonce);
    body.append('product_id', productId);
    if (quantity != null) body.append('quantity', quantity);
    const res = await fetch(ajaxUrl, { method: 'POST', credentials: 'same-origin', body });
    return res.json();
  }

  function findCardContainer(el) {
    // The stepper lives inside the product <li>, so anchor it to that card.
    return el.closest('li.product') || el.closest('.product');
  }

  async function ensureStepper(card, productId) {
    const existing = card.querySelector('.snb-card-stepper');
    if (existing) return existing;

    // Hide the round cart button + remove WooCommerce's "view cart" link so it
    // can never flash during layout/reflow.
    const btn = card.querySelector('.add_to_cart_button') || card.querySelector('a.button[data-product_id]');
    if (btn) btn.classList.add('added');
    const viewLink = card.querySelector('a.added_to_cart');
    if (viewLink) viewLink.remove();

    const qty0 = stepperQty[productId] || 1;
    const { wrap, qty } = buildStepper(productId, qty0);
    card.appendChild(wrap);

    const setQty = async (newQty) => {
      const r = await cardCartPost('senoobar_cart_set_quantity', productId, newQty);
      if (r && r.success) {
        qty.textContent = newQty;
        stepperQty[productId] = newQty;
        if (window.jQuery) window.jQuery(document.body).trigger('wc_fragment_refresh');
      }
    };

    const remove = async () => {
      const r = await cardCartPost('senoobar_cart_remove_by_product', productId);
      if (r && r.success) {
        delete stepperQty[productId];
        wrap.remove();
        // Restore the round add-to-cart button (the .added_to_cart link stays
        // removed; WooCommerce may re-add it on the next AJAX update).
        const b = card.querySelector('.add_to_cart_button') || card.querySelector('a.button[data-product_id]');
        if (b) b.classList.remove('added');
        if (window.jQuery) window.jQuery(document.body).trigger('wc_fragment_refresh');
      }
    };

    wrap.querySelector('.snb-card-plus').addEventListener('click', () => {
      const cur = parseInt(qty.textContent, 10) || 1;
      setQty(cur + 1);
    });
    wrap.querySelector('.snb-card-minus').addEventListener('click', () => {
      const cur = parseInt(qty.textContent, 10) || 1;
      if (cur <= 1) {
        remove();
      } else {
        setQty(cur - 1);
      }
    });
    wrap.querySelector('.snb-card-del').addEventListener('click', remove);

    return wrap;
  }

  function initCardCartStepper() {
    // Fully self-contained add-to-cart + stepper for loop buttons (home/shop/
    // archive). We do the AJAX add ourselves via the custom endpoint
    // (senoobar_cart_set_quantity) with plain fetch() — exactly like the single-
    // product buy-box — so it never depends on the WooCommerce ajax setting,
    // jQuery, or wc-add-to-cart.js being present. The click is intercepted to
    // prevent the full page reload that would otherwise follow the href.
    document.addEventListener('click', (e) => {
      const addBtn = e.target.closest('.add_to_cart_button');
      if (!addBtn) return;
      const card = findCardContainer(addBtn);
      const pid = Number(addBtn.getAttribute('data-product_id') || 0);
      if (!pid || !card) return;

      // Prevent navigation / page reload. Do NOT stopPropagation here so other
      // handlers (e.g. any future analytics) still observe the click.
      e.preventDefault();

      // Start fading the round icon out immediately for a continuous morph.
      addBtn.classList.add('added');

      // Perform the add via our own endpoint (idempotent — sets qty 1 when the
      // product is not yet in the cart), update the cart badge, then build the
      // stepper.
      cardCartPost('senoobar_cart_set_quantity', pid, 1)
        .then((r) => {
          if (r && r.success) {
            stepperQty[pid] = 1;
            // Refresh the header/bottom cart badge counts directly.
            const count = (r && typeof r.cart_count === 'number')
              ? r.cart_count
              : (r.data && typeof r.data.cart_count === 'number' ? r.data.cart_count : null);
            if (typeof count === 'number') {
              document.querySelectorAll('.cart-badge[data-cart-count], .mbn-badge[data-cart-count]').forEach((b) => {
                b.textContent = String(count);
                if (count > 0) b.classList.remove('is-hidden');
                else b.classList.add('is-hidden');
              });
            }
          }
          ensureStepper(card, pid);
        })
        .catch(() => {
          // Fallback: let the browser follow the normal link.
          if (addBtn.getAttribute('href')) window.location.href = addBtn.getAttribute('href');
        });
    });

    // On page load, any card already "added" (e.g. after an AJAX refresh or a
    // non-AJAX reload) gets a stepper.
    document.addEventListener('DOMContentLoaded', () => {
      $$('.add_to_cart_button.added').forEach((btn) => {
        const card = findCardContainer(btn);
        const pid = Number(btn.getAttribute('data-product_id') || 0);
        if (card && pid) ensureStepper(card, pid);
      });
    });
  }

  // ── Boot ───────────────────────────────────────────
  function boot() {
    initPage();
    initHeartButtons();
    initCardCartStepper();
  }
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }
})();
